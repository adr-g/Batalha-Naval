#include "Barco.h"

using namespace std;

int Barco::get_type_Boat()
{
    if (type_boat <= 0)
    {
        cout << "\nErro N_xxxx\n";
        exit(0);
    }
    else
    {
        return type_boat;
    }
}

int Barco::get_initialization_l() const
{
	return  initialization[0];
}

int Barco::get_initialization_c() const
{
	return initialization[1];
}

int Barco::get_final_l() const
{
	return final[0];
}

int Barco::get_final_c() const
{
	return final[1];

}

void Barco::generate_boat(int type, Tabuleiro& tp)
{
   

    if (type > 0 && type < 6)
    {
        type_boat = type;

    }
    else
    {
        cout << "\nErro N_xxxx\n";
        system("pause");
        exit(0);
    }

    bool atempt = true;

    if (type == 5)
    {

    }
    else
    {
             srand(time(NULL));

            int l_i=0, c_i=0, l_f=0, c_f=0;
            bool verificador = true;
            
            do
            {
                Sleep(1.1);
                
                if ((1 + rand() % 1000) % 2 == 0)
                {
                    l_i = rand() % tp.getDimX();
                    l_f = l_i;

                    c_i = rand() % (tp.getDimY() - type);
                    c_f = c_i + type-1;

                    if (c_f >= tp.getDimY())
                    {
                        cout << "\nErro...N_xxxx\n";
                        system("pause");
                    }
                    else
                    {
                        if (dev_mode == true)
                        {
                            cout << "l_i=" << l_i << "  l_f=" << l_f << "  c_i=" << c_i << "  c_f=" << c_f << "  type=" << type << "\n\n";
                            system("pause");
                        }
                       
                        int contador = 0;
                        for (int i = c_i; i <= c_f; i++)
                        {
                            if (tp.tabuleiro[l_i][i] == '.')
                            {
                                contador++;
                            }
                        }

                        if (contador == type)
                        {
                            int contador_2 = 0;

                            if (dev_mode == true)
                            {
                                cout << "\nLivre, verificar dos lados\n";

                            }

                            //dev mode 
                            char tabuleiro_2[10][10];
                            
                            for (int k = 0; k < 10; k++)
                            {
                                for (int i = 0; i < 10; i++)
                                {
                                    tabuleiro_2[k][i] = '.';
                                }
                            }
                            bool verificar_2 = true;
                            
                            for (int i = c_i; i <= c_f; i++)
                            {
                                if (l_i-1>=0)
                                {
                                    if (l_i == tp.getDimX() - 1)
                                    {
                                        if (tp.tabuleiro[l_i - 1][i] == '.')
                                        {
                                            contador_2++;
                                            tabuleiro_2[l_i - 1][i] = '@';
                                        }
                                        else
                                        {
                                            verificar_2 = false;
                                        }
                                    }
                                    else
                                    {
                                       
                                        if (tp.tabuleiro[l_i - 1][i] == '.')
                                        {
                                            tabuleiro_2[l_i - 1][i] = '@';
                                            contador_2++;
                                        }
                                        else
                                        {
                                            verificar_2 = false;
                                        }

                                        if (tp.tabuleiro[l_i + 1][i] == '.')
                                        {
                                           tabuleiro_2[l_i + 1][i] = '@';
                                            contador_2++;
                                        }
                                        else
                                        {
                                            verificar_2 = false;
                                        }
                                    }
                                }
                                else
                                {
                                    if (tp.tabuleiro[l_i + 1][i] == '.')
                                    {
                                        contador_2++;
                                        tabuleiro_2[l_i+1][i] = '@';
                                    }
                                    else
                                    {
                                        verificar_2 = false;
                                    }
                                }
                            }
                            if ((contador_2 == type && verificar_2==true) || (contador_2 == (2 * type) && verificar_2==true ))
                            {
                                contador = 0;
                                if (c_i > 0 && c_f<tp.getDimY()-1)
                                {
                                    if (tp.tabuleiro[l_i][c_i-1] == '.')
                                    {
                                        tabuleiro_2[l_i][c_i - 1] = '@';
                                        contador++;
                                    }
                                    if (tp.tabuleiro[l_i][c_f + 1] == '.')
                                    {
                                        tabuleiro_2[l_i][c_f + 1] = '@';
                                        contador++;
                                    }
                                    if (contador == 2)
                                    {
                                        if (dev_mode == true)
                                        {
                                            cout << "\nLivre dos Lados\n";
                                        } 
                                        contador = 666;
                                    }
                                }
                                else
                                {
                                    if (c_i == 0)
                                    {
                                        
                                        if (tp.tabuleiro[l_i][c_f + 1] == '.')
                                        {
                                            tabuleiro_2[l_i][c_f + 1] = '@';
                                            contador++;
                                        }
                                    }
                                    else
                                    {
                                        if (dev_mode == true)
                                        {
                                            cout << endl << c_i << endl;
                                        }
                                        if (tp.tabuleiro[l_i][c_i - 1] == '.')
                                        {
                                            tabuleiro_2[l_i][c_i - 1] = '@';
                                            contador++;
                                        }
                                    }
                                    if (contador == 1)
                                    {
                                        if (dev_mode ==true)
                                        {
                                            cout << "\nLivre dos Lados\n";
                                        }
                                        contador = 666;
                                    }
                                }
                                if (contador == 666)
                                {
                                    for (int j = c_i; j <= c_f; j++)
                                    {
                                        tp.tabuleiro[l_i][j] = 'O';
                                    }
                                    initialization[0] = l_i;
                                    final[0] = l_f;
                                    initialization[1] = c_i;
                                    final[1] = c_f;
                                    type_boat = type;
                                    verificador = false;
                                }
                            }
                            if (dev_mode ==true)
                            {
                                cout << "\n\n\n Verificar dos lados \n\n\n";
                                for (int i = 0; i < tp.getDimX(); i++)
                                {
                                    for (int j = 0; j < tp.getDimY(); j++)
                                    {
                                        cout << "  " << tabuleiro_2[i][j];
                                    }
                                    cout << endl;
                                }
                                cout << "\n\n";
                                system("pause");
                            }  
                        }
                    }
                }
                else
                {
                    Sleep(1);

                    l_i = rand() % (tp.getDimX()-type);
                    l_f = l_i+type-1;

                    c_i = rand() % tp.getDimY() ;
                    c_f = c_i;
                   
                    if (l_f >= tp.getDimY())
                    {
                        cout << "\nErro N_xxxx\n";
                        system("pause");
                    }
                    else
                    {
                        if (dev_mode == true)
                        {
                            cout << "l_i=" << l_i << "  l_f=" << l_f << "  c_i=" << c_i << "  c_f=" << c_f  << "  type=" << type << "\n\n";
                            system("pause");
                        }    
                        int contador = 0;
                        //dev mod 
                        char tabuleiro_2[10][10];
                        for (int k = 0; k < 10; k++)
                        {
                            for (int i = 0; i < 10; i++)
                            {
                                tabuleiro_2[k][i] = '.';
                            }
                        }
                        for (int i = l_i; i <= l_f; i++)
                        {
                            if (tp.tabuleiro[i][c_i] == '.')
                            {
                                contador++;
                            }
                        }
                        if (contador == type)
                        {
                            int contador_2 = 0;
                            if (dev_mode == true)
                            {
                                cout << "\nLivre, verificar os lados\n";
                            }
                            bool verificar_2=true;
                            for (int i = l_i; i <= l_f; i++)
                            {
                                if (c_i - 1 >= 0)
                                {
                                    if (c_i == tp.getDimX() - 1)
                                    {
                                        if (tp.tabuleiro[i][c_i-1] == '.')
                                        {
                                            tabuleiro_2[i][c_i - 1] = '@';
                                            contador_2++;
                                        }
                                        else
                                        {
                                            verificar_2 = false;
                                        }
                                    }
                                    else
                                    {
                                        if (tp.tabuleiro[i][c_i-1] == '.')
                                        {
                                            tabuleiro_2[i][c_i - 1] = '@';
                                            contador_2++;
                                        }
                                        else
                                        {
                                            verificar_2 = false;
                                        }

                                        if (tp.tabuleiro[i][c_i+1] == '.')
                                        {
                                            tabuleiro_2[i][c_i + 1] = '@';
                                            contador_2++;
                                        }
                                        else
                                        {
                                            verificar_2 = false;
                                        }
                                    }
                                }
                                else
                                {
                                    if (tp.tabuleiro[i][c_i+1] == '.')
                                    {
                                        tabuleiro_2[i][c_i + 1] = '@';
                                        contador_2++;
                                    }
                                    else
                                    {
                                        verificar_2 = false;
                                    }
                                }
                            }
                            if ((contador_2 == type && verificar_2==true) || (contador_2 == (2 * type) && verificar_2==true ))
                            {
                                contador = 0;
                                if (l_i > 0 && l_f < tp.getDimX() - 1)
                                {
                                    if (tp.tabuleiro[l_i-1][c_i ] == '.')
                                    {
                                        contador++;
                                        tabuleiro_2[l_i - 1][c_i] = '@';
                                    }
                                    if (tp.tabuleiro[l_f+1][c_i] == '.')
                                    {
                                        contador++;
                                        tabuleiro_2[l_f + 1][c_f] = '@';
                                    }
                                    if (contador == 2)
                                    {
                                        if (dev_mode == true)
                                        {
                                            cout << "\nLivre dos Lados\n";
                                            
                                        }
                                        contador = 666;
                                       
                                    }
                                }
                                else
                                {
                                    if (l_i == 0)
                                    {

                                        if (tp.tabuleiro[l_f+1][c_i] == '.')
                                        {
                                            tabuleiro_2[l_f+1][c_i] = '@';
                                            contador++;
                                        }
                                    }
                                    else
                                    {
                                        cout << endl << c_f << endl;
                                        if (tp.tabuleiro[l_i-1][c_i] == '.')
                                        {
                                            tabuleiro_2[l_i - 1][c_i] = '@';
                                            contador++;
                                        }
                                    }
                                    if (contador == 1)
                                    {
                                        if (dev_mode==true)
                                        {
                                            cout << "\nLivre dos Lados\n";   
                                        }
                                        contador = 666;
                                    }
                                }
                                if (contador == 666)
                                {
                                    for (int j = l_i; j <= l_f; j++)
                                    {
                                        tp.tabuleiro[j][c_i] = 'O';
                                        initialization[0] = l_i;
                                        final[0] = l_f;
                                        initialization[1] = c_i;
                                        final[1] = c_f;
                                        type_boat = type;
                                    }
                                    verificador = false;
                                }
                            }
                            if (dev_mode==true)
                            {
                                cout << "\n\n\n Verificar dos lados \n\n\n";
                                for (int i = 0; i < tp.getDimX(); i++)
                                {
                                    for (int j = 0; j < tp.getDimY(); j++)
                                    {
                                        cout << "   " << tabuleiro_2[i][j];
                                    }
                                    cout << endl;
                                }
                                cout << "\n\n";
                                system("pause");
                            }
                        }
                    }
                }
            } while (verificador==true);

            if (dev_mode == true)
            {
                cout << "\n\n";
                for (int i = 0; i < tp.getDimX(); i++)
                {
                    for (int j = 0; j < tp.getDimY(); j++)
                    {
                        cout << "   " << tp.tabuleiro[i][j];
                    }
                    cout << endl;
                }
            }
    }
}

void Barco::set_dev_mode(bool dev_mode)
{
    dev_mode = dev_mode;
}

void Barco::set_user_boat(int type, Tabuleiro& t1,Tabuleiro& t2)
{
    bool vereficar=true;
    int direction = -123;
    int l = 0;
    char c = '@';
    int guarda=-57;
    char letras[10] = { 'a','b','c','d','e','f','g','h','i','j' };

    while (vereficar==true)
    {
        if (type > 1)
        {
            cout << "Qual a dire��o do navio:";
            desenhar_essencial(t1, t2);
        }
        bool vereficador_2 = true;
        while (vereficador_2==true)
        {
            desenhar_essencial(t1, t2);
            gotoxy(31, 31);
            cout << "Qual a sua linha??";
            cin >> l;
           
            if (l <= 10 && l >= 1)
            {
                desenhar_essencial(t1,t2);
                cout << "Qual a sua coluna?? ";
                cin >> c;
                for (int a = 0; a < 10; a++)
                {
                    if (letras[a] == c)
                    {
                        vereficador_2 =false;
                        guarda = a;
                    }
                }
                if (guarda == -57)
                {
                    guarda = -57;
                    l = 0;
                    c = '@';
                    desenhar_essencial(t1,t2);
                    cout << "Erro N_xxxx";
                    Sleep(5000);
                }
            }
            else
            {
                guarda = -57;
                l = 0;
                c = '@';
                desenhar_essencial(t1,t2);
                cout << "Erro N_xxxx";
                Sleep(5000);    
            }
        }
        l = l - 1;
        switch (direction)
        {
            case -123:
            {
                if (t1.tabuleiro[l][guarda] == '.')
                {
                    t1.tabuleiro[l][guarda] = 'O';
                    vereficar = false;
                }
                else
                {
                    desenhar_essencial(t1, t2);
                    cout << "Lugar ja esta ocupado";
                    Sleep(5000);
                }
                break;
            }
            case 1:
            {
                
                break;
            }
            case 2:
            {
                break;
            }
            default:
            {
                cout << "Erro N_xxxx\n\n\n";
                system("pause");
                exit(0);
                break;
            }
        }
    }
}
void Barco::desenhar_essencial(Tabuleiro &t1,Tabuleiro &t2)
{
    system("cls");
    gotoxy(75, 0);
    t2.Draw(75, 5,false);
    gotoxy(0, 0);
    t1.Draw(27, 5,true);

    gotoxy(26, 3);
    cout << "JOGADOR";
    gotoxy(110, 3);
    cout << "COMPUTADOR";
    showRectAt(25, 4, 48, 24);
    showRectAt(73, 4, 48, 24);

    show90RectAt(25, 30, 10, 48);
    gotoxy(26, 31);
}