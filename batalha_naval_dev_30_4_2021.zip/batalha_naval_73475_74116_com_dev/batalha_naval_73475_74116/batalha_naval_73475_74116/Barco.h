#pragma once
#include <iostream>
#include <algorithm>
#include <time.h> 
#include "Tabuleiro.h"
#include "lab.h"

using namespace std;
class Barco
{
    private:
        /*
        int subx;
        int suby;
        */
        int initialization[2];
        int final[2];
        int type_boat = -10;
        bool dev_mode = false;
    public:
        //l=linha c=coluna

        int get_type_Boat();

        int get_initialization_l() const;
       
        int get_initialization_c() const;

        int get_final_l() const;
        
        int get_final_c() const;
       
        void generate_boat(int type,Tabuleiro &tp);

        void set_dev_mode(bool dev_mode);

        void set_user_boat(int type, Tabuleiro& t1,Tabuleiro& t2);

        void desenhar_essencial(Tabuleiro& t1, Tabuleiro& t2);
};