#pragma once
#include <iostream>
#include <xiosbase>
#include <string>
#include "Barco.h"

using namespace std;

class Jogador
{
	public:

		string nome;

		Barco  submarinos[4], contratorpedeiro[3], cruzador[2], couracado;


	private:
		bool naviosDestruidos[11];
};