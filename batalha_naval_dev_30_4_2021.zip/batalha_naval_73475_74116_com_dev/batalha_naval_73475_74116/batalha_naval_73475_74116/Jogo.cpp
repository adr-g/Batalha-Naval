#include "Jogo.h"


using namespace std;


Jogo::Jogo()
{
	
	
	
	
	

}

Jogo::~Jogo()
{
	

}

bool Jogo::Demo()
{
	return false;
}

void Jogo::Jogo_Novo()
{
	int i = 0, j = 0;
	cout << "\nQual o nome do player 1?";
	getline(cin, player1.nome);


	cout << "\nQual o nome do player 2?";
	getline(cin, player2.nome);
	t1.set_dev_mode(dev_mode);
	t2.set_dev_mode(dev_mode);
	

	gerarBarcos();
	system("cls");
	DrawBoards();
	//set_user_boats();

}

bool Jogo::Save(string file)
{
	return false;
}

bool Jogo::Read(string file)
{
	return false;
}

bool Jogo::Preenche_tabuleiros()
{
	return false;
}

bool Jogo::Show_tabuleiros()
{
	return false;
}


void Jogo::DrawBoards()
{
	Barco submarino[4];
	submarino[0].desenhar_essencial(t1,t2);


	cout << "E necessario prencher o seu tabuleiro antes de continuar...(5s)";


	Sleep(5000);

	
	submarino[0].desenhar_essencial(t1, t2);

	submarino[0].set_user_boat(1,t1,t2);
	submarino[0].desenhar_essencial(t1, t2);
	system("pause");


	system("pause");

	/*
	int i;
	int cli[4];
	char cl[4];
	int cn[4];
	char letras[10] = { 'a','b','c','d','e','f','g','h','i','j' };
	int savedc[4][2];

	gotoxy(75, 0);
	t2.Draw(75, 5);
	gotoxy(0, 0);
	t1.Draw(27, 5);

	gotoxy(26, 3);
	cout << "JOGADOR";
	gotoxy(110, 3);
	cout << "COMPUTADOR";
	showRectAt(25, 4, 48, 24);
	showRectAt(73, 4, 48, 24);

	show90RectAt(25, 30, 10, 48);

	for (i = 0; i < 4; i++)
	{
		gotoxy(26, 31);
		cout << "Insira o " << i + 1 << " numero a colocar:     " << endl; ;
		gotoxy(58, 31);
		do
		{
			cin >> cn[i];
			if (cn[i] < 1 || cn[i] > 10)
			{
				gotoxy(26, 31);
				cout << "                                              ";
				gotoxy(26, 31);
				cout << "Insira o " << i + 1 << " numero a colocar:     " << endl; ;
				gotoxy(26, 33);
				cout << "O numero precisa de estar contido entre 1 e 10!";
				gotoxy(58, 31);
			}

		} while (cn[i] < 1 || cn[i] > 10);
		savedc[i][0] = cn[i];
		gotoxy(26, 33);
		cout << "                                              ";
		cout << endl;
		gotoxy(26, 31);
		cout << "Insira a " << i + 1 << " letra a colocar:      " << endl;
		gotoxy(58, 31);
		do
		{
			cin >> cl[i];
			if (!strchr(letras, cl[i]))
			{
				gotoxy(26, 31);
				cout << "                                              ";
				gotoxy(26, 31);
				cout << "Insira a " << i + 1 << " letra a colocar:     " << endl; ;
				gotoxy(26, 33);
				cout << "A letra precisa de estar contida entre A e J!";
				gotoxy(58, 31);
			}
		} while (!strchr(letras, cl[i]));
		cli[i] = int(cl[i] - 96);
		savedc[i][1] = cli[i];
		gotoxy(26, 33);
		cout << "                                              ";
		cout << endl;

		//verificar se ponto de cordenadas ja existe
		bool check = checkCords(cn[i], cli[i], savedc, i);
		while (check)
		{
			gotoxy(26, 31);
			cout << "Insira o " << i + 1 << " numero a colocar:     " << endl;
			gotoxy(26, 33);
			cout << "Esse ponto de coordenadas ja existe!";
			gotoxy(58, 31);
			do
			{
				cin >> cn[i];
				if (cn[i] < 1 || cn[i] > 10)
				{
					gotoxy(26, 31);
					cout << "                                              ";
					gotoxy(26, 31);
					cout << "Insira o " << i + 1 << " numero a colocar:     " << endl; ;
					gotoxy(26, 33);
					cout << "O numero precisa de estar contido entre 1 e 10!";
					gotoxy(58, 31);
				}
			} while (cn[i] < 1 || cn[i] > 10);
			gotoxy(26, 33);
			cout << "                                              ";
			cout << endl;
			gotoxy(26, 31);
			cout << "Insira a " << i + 1 << " letra a colocar:      " << endl;
			gotoxy(58, 31);
			do
			{
				cin >> cl[i];
				if (!strchr(letras, cl[i]))
				{
					gotoxy(26, 31);
					cout << "                                              ";
					gotoxy(26, 31);
					cout << "Insira a " << i + 1 << " letra a colocar:     " << endl; ;
					gotoxy(26, 33);
					cout << "A letra precisa de estar contida entre A e J!";
					gotoxy(58, 31);
				}

			} while (!strchr(letras, cl[i]));
			gotoxy(26, 33);
			cout << "                                              ";
			cout << endl;
			check = checkCords(cn[i], cli[i], savedc, i);
		}
		savedc[i][0] = cn[i];
		cli[i] = int(cl[i] - 96);
		savedc[i][1] = cli[i];
	}

	system("cls");

	gotoxy(75, 0);
	t2.Draw(75, 5);
	gotoxy(0, 0);
	t1.Draw(27, 5);

	gotoxy(26, 3);
	cout << "JOGADOR";
	gotoxy(110, 3);
	cout << "COMPUTADOR";
	showRectAt(25, 4, 48, 24);
	showRectAt(73, 4, 48, 24);
	*/
}

bool Jogo::checkCords(int x, int y, int cords[4][2], int pos)
{
	bool exists = false;
	for (int i = 0; i < 4; i++)
	{
		if (i == pos)
		{
			continue;
		}
		else
		{
			if (x == cords[i][0] && y == cords[i][1])
			{
				exists = true;
			}
		}
	}
	return exists;
}

void Jogo::gerarBarcos()
{
	int i = 0;

	for (i = 0; i < 4; i++)
	{
		if (dev_mode == true)
		{
			player2.submarinos[i].set_dev_mode(true);
		}
		player2.submarinos[i].generate_boat(1, t2);
	}
	system("cls");
	for (i = 0; i < 3; i++)
	{
		if (dev_mode == true)
		{
			player2.contratorpedeiro[i].set_dev_mode(true);
		}
		player2.contratorpedeiro[i].generate_boat(2, t2);
	}
	for (i = 0; i < 2; i++)
	{
		if (dev_mode == true)
		{
			player2.cruzador[i].set_dev_mode(true);
		}
		player2.cruzador[i].generate_boat(3, t2);
	}
	if (dev_mode == true)
	{
		player2.couracado.set_dev_mode(true);
	}
	player2.couracado.generate_boat(4, t2);
	if (dev_mode == true)
	{
		system("pause");
		system("cls");
	}
}

void Jogo::set_user_boats()
{
	Barco sub;
	sub.set_user_boat(1,t1,t2);
}

void Jogo::set_dev_mode(bool dev_mode)
{
	dev_mode = dev_mode;
}