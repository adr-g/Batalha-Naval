#pragma once

#include "Jogador.h"
#include "Tabuleiro.h"
#include "Barco.h"
#include <iostream>
#include "Jogador.h"

using namespace std;

class Jogo 
{
    private:
        Jogador player1, player2;
        bool dev_mode = false;
        Tabuleiro t1, t2;
        
    public:
        Jogo();
        virtual ~Jogo();
        bool Demo();
        void Jogo_Novo();
        virtual bool Save(string file);
        virtual bool Read(string file);
        bool Preenche_tabuleiros();
        bool Show_tabuleiros();

        void DrawBoards();
        bool checkCords(int x, int y, int cords[4][2], int pos);
        void gerarBarcos( );
        void set_user_boats();
        void set_dev_mode(bool dev_mode);
};