#include "PontoNaval.h"
#include <iostream>


using namespace std;

PontoNaval::PontoNaval()
{
    x = 1;
    y = 'A';
}

PontoNaval::PontoNaval(int m_x, char m_y) {
    Setx(m_x);
    Sety(m_y);
}

PontoNaval::PontoNaval(int m_x, int m_y) {
    Setx(m_x);
    Sety(m_y);
}

PontoNaval::~PontoNaval() {}

bool PontoNaval::Setx(int m_x) {
    if (m_x >= 1 && m_x <= 10) {
        x = m_x;
        return true;
    }

    cout << "Valor de x nao e invalido" << endl;
    return false;

}

bool PontoNaval::Sety(char m_y) {
    if (m_y >= 'A' && m_y <= 'J') {
        y = m_y;
        return true;
    }

    cout << "Valor de y nao e invalido" << endl;
    return false;

}

bool PontoNaval::Sety(int m_y) {
    if (m_y >= 1 && m_y <= 10) {
        y = char(64 + m_y);
        return true;
    }

    cout << "Valor de y nao e invalido" << endl;
    return false;

}


int PontoNaval::Getinty() {
    int aux;
    aux = int(y) - 64;
    return aux;
}


void PontoNaval::Ask2Set_PN() {
    int aux_x;
    char aux_y;

    cout << "Insira um valor de x: ";
    do {
        cin >> aux_x;
    } while (!Setx(aux_x));
    cout << "Insira um valor de y: ";
    do {
        cin >> aux_y;
    } while (!Sety(aux_y));

}

void PontoNaval::ShowPontoNaval() {
    cout << "(" << Getx() << "," << Gety() << ")" << endl;
}

bool PontoNaval::operator == (const PontoNaval ponto) const {
    if (Getx() == ponto.Getx() && Gety() == ponto.Gety()) {
        return true;
    }

    return false;
}

bool PontoNaval::operator != (const PontoNaval ponto) const {
    if (Getx() != ponto.Getx() || Gety() != ponto.Gety()) {
        return true;
    }
    return false;
}
