#pragma once
class PontoNaval
{
    private:
        int x; //1 -- 10
        char y; //A -- J
    public:

        PontoNaval();

        PontoNaval(int m_x, char m_y);

        PontoNaval(int m_x, int m_y);

        ~PontoNaval();

        bool Setx(int m_x);

        bool Sety(char m_y);

        bool Sety(int m_y);

        //void SetPN(int m_x, char m_y);

        //void SetPN(PontoNaval m_PN);

        void Ask2Set_PN();

        int Getx() const 
        {
            return x;
        }

        char Gety() const
        {
            return y;
        }

        int Getinty();

        //bool IsValid();

        void ShowPontoNaval();

        bool operator == (const PontoNaval ponto) const;

        bool operator != (const PontoNaval ponto) const;

        //void operator = (PontoNaval ponto);

        //void Save(ofstream &os);

        //void Read(ifstream &is);
};